import { type FormEvent, type ReactNode, useEffect, useMemo, useState } from 'react';
import { Link, Route, Switch, Router as WouterRouter, useLocation } from 'wouter';
import {
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  BookOpen,
  Check,
  ChevronDown,
  Clock3,
  Compass,
  Facebook,
  Linkedin,
  Mail,
  MessageCircle,
  MapPin,
  Menu,
  Play,
  Send,
  Target,
  Users,
  X,
} from 'lucide-react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import logo from '@assets/ccwarsame-01_1789745210318.png';
import portrait from '@assets/IMG_0117_1789743142205.png';

const queryClient = new QueryClient();

const navItems = [
  { href: '/', label: 'Home' },
  { href: '/about', label: 'About' },
  { href: '/services', label: 'Services' },
  { href: '/resources', label: 'Resources' },
];

const consultationLink = 'https://haltap.com/share/HT123456';
const socialLinks = {
  facebook: 'https://www.facebook.com/share/1crpuTJ3c4/?mibextid=wwXIfr',
  linkedin: 'https://www.linkedin.com/in/abdullahi-warsame-8baa2424b?utm_source=share_via&utm_content=profile&utm_medium=member_ios',
  whatsapp: 'https://wa.me/252612236088',
};

type Resource = {
  id: string;
  type: string;
  title: string;
  description: string;
  readTime: string;
  color: 'blue' | 'lime' | 'ink';
};

const resources: Resource[] = [
  { id: 'sales-rhythm', type: 'Field note', title: 'The weekly sales rhythm that keeps a team moving', description: 'A practical operating cadence for turning scattered activity into clear next steps and better conversations.', readTime: '6 min read', color: 'blue' },
  { id: 'support-system', type: 'Guide', title: 'Customer support is a growth system', description: 'What to document, measure, and improve when the customer experience is becoming everyone’s job.', readTime: '8 min read', color: 'lime' },
  { id: 'marketing-brief', type: 'Template', title: 'The one-page marketing brief', description: 'A sharper starting point for campaigns, launches, and the teams who need to execute them.', readTime: 'Downloadable', color: 'ink' },
  { id: 'team-retro', type: 'Workshop note', title: 'A better way to run a team retrospective', description: 'Questions that move a retrospective beyond reporting and into honest, useful improvement.', readTime: '5 min read', color: 'blue' },
  { id: 'growth-audit', type: 'Checklist', title: 'The practical growth audit', description: 'A clear look at the habits, handoffs, and systems holding your next stage of growth together.', readTime: '12 min read', color: 'lime' },
  { id: 'video-office-hours', type: 'Video', title: 'Office hours: finding the friction', description: 'A short walkthrough of how to spot the bottleneck before you add another tool or hire another person.', readTime: '14 min watch', color: 'ink' },
];

function PageScrollManager() {
  const [location] = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'auto' });
    const labels: Record<string, string> = { '/': 'Home', '/about': 'About', '/services': 'Services', '/resources': 'Resources', '/contact': 'Contact' };
    document.title = `${labels[location] ?? 'Page'} — CCWARSAME`;
  }, [location]);
  return null;
}

function SiteHeader() {
  const [location] = useLocation();
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-40 border-b border-[hsl(var(--foreground)/.12)] bg-[hsl(var(--background)/.93)] backdrop-blur-md" data-testid="site-header">
      <div className="page-shell flex h-[76px] items-center justify-between gap-5">
        <Link href="/" className="focus-ring shrink-0" onClick={() => setOpen(false)} data-testid="link-brand-home" aria-label="CCWARSAME home">
          <img src={logo} alt="CC Warsame" className="h-14 w-[150px] object-contain" data-testid="img-brand-logo" />
        </Link>
        <nav className="hidden items-center gap-8 md:flex" aria-label="Main navigation" data-testid="main-navigation">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={`link-underline focus-ring text-[.79rem] font-bold tracking-[.01em] ${location === item.href ? 'text-[hsl(var(--primary))]' : 'text-[hsl(var(--foreground)/.7)] hover:text-foreground'}`}
              data-testid={`link-nav-${item.label.toLowerCase()}`}
            >
              {item.label}
            </Link>
          ))}
        </nav>
        <a href={consultationLink} target="_blank" rel="noreferrer" className="button-sweep focus-ring hidden items-center gap-3 rounded-full bg-foreground px-5 py-3 text-[.72rem] font-extrabold uppercase tracking-[.1em] text-background sm:flex" data-testid="link-header-contact">
          <span>Work with me</span><ArrowUpRight size={15} strokeWidth={2.5} />
        </a>
        <button type="button" className="focus-ring rounded-full border border-foreground/20 p-2 md:hidden" onClick={() => setOpen(!open)} aria-expanded={open} aria-label={open ? 'Close navigation' : 'Open navigation'} data-testid="button-mobile-menu">
          {open ? <X size={21} /> : <Menu size={21} />}
        </button>
      </div>
      {open && (
        <div className="border-t border-foreground/10 bg-background px-5 py-5 md:hidden" data-testid="mobile-navigation">
          <nav className="page-shell flex flex-col gap-1" aria-label="Mobile navigation">
            {navItems.map((item) => (
              <Link key={item.href} href={item.href} onClick={() => setOpen(false)} className="focus-ring flex items-center justify-between border-b border-foreground/10 py-4 text-lg font-bold" data-testid={`link-mobile-${item.label.toLowerCase()}`}>
                <span>{item.label}</span><ArrowRight size={17} />
              </Link>
            ))}
            <a href={consultationLink} target="_blank" rel="noreferrer" onClick={() => setOpen(false)} className="mt-4 flex items-center justify-between rounded-full bg-[hsl(var(--primary))] px-5 py-4 text-sm font-extrabold uppercase tracking-wider text-foreground" data-testid="link-mobile-contact">
              <span>Work with me</span><ArrowUpRight size={17} />
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}

function Footer() {
  return (
    <footer className="bg-foreground text-background" data-testid="site-footer">
      <div className="page-shell py-16 md:py-20">
        <div className="grid gap-12 md:grid-cols-[1.35fr_.7fr_.7fr]">
          <div>
            <img src={logo} alt="CC Warsame" className="h-14 w-[145px] object-contain object-left brightness-0 invert" data-testid="img-footer-logo" />
            <p className="mt-6 max-w-sm text-[1.03rem] leading-7 text-background/65">Practical growth thinking for business owners and teams building what comes next.</p>
            <div className="mt-7 flex items-center gap-3">
              <a href={socialLinks.facebook} target="_blank" rel="noreferrer" className="focus-ring rounded-full border border-background/20 p-3 transition hover:border-[hsl(var(--primary))] hover:text-[hsl(var(--primary))]" aria-label="Facebook" data-testid="link-footer-facebook"><Facebook size={16} /></a>
              <a href={socialLinks.linkedin} target="_blank" rel="noreferrer" className="focus-ring rounded-full border border-background/20 p-3 transition hover:border-[hsl(var(--primary))] hover:text-[hsl(var(--primary))]" aria-label="LinkedIn" data-testid="link-footer-linkedin"><Linkedin size={16} /></a>
              <a href={socialLinks.whatsapp} target="_blank" rel="noreferrer" className="focus-ring rounded-full border border-background/20 p-3 transition hover:border-[hsl(var(--primary))] hover:text-[hsl(var(--primary))]" aria-label="WhatsApp" data-testid="link-footer-whatsapp"><MessageCircle size={16} /></a>
            </div>
          </div>
          <div>
            <p className="eyebrow text-[hsl(var(--secondary))]">Explore</p>
            <div className="mt-5 flex flex-col items-start gap-3 text-sm text-background/65">
              {navItems.map((item) => <Link key={item.href} href={item.href} className="link-underline hover:text-background" data-testid={`link-footer-${item.label.toLowerCase()}`}>{item.label}</Link>)}
            </div>
          </div>
          <div>
            <p className="eyebrow text-[hsl(var(--secondary))]">Start a conversation</p>
            <a href="mailto:hello@ccwarsame.com" className="focus-ring mt-5 inline-flex items-center gap-2 text-sm text-background/75 hover:text-background" data-testid="link-footer-email"><Mail size={15} /> hello@ccwarsame.com</a>
            <p className="mt-4 flex items-center gap-2 text-sm text-background/50"><MapPin size={15} /> Working globally from East Africa</p>
          </div>
        </div>
        <div className="mt-14 flex flex-col justify-between gap-3 border-t border-background/15 pt-5 text-xs text-background/45 sm:flex-row">
          <span data-testid="text-footer-copyright">© {new Date().getFullYear()} CCWARSAME. All rights reserved.</span>
          <span data-testid="text-footer-philosophy">Build the Skills. Create the Systems. Drive Growth.</span>
        </div>
      </div>
    </footer>
  );
}

function PageFrame({ children }: { children: ReactNode }) {
  return <><SiteHeader /><main>{children}</main><Footer /></>;
}

function SectionTag({ children, color = 'blue' }: { children: ReactNode; color?: 'blue' | 'lime' | 'ink' }) {
  const styles = color === 'lime' ? 'bg-[hsl(var(--secondary))]' : color === 'ink' ? 'bg-foreground text-background' : 'bg-[hsl(var(--primary))]';
  return <span className={`eyebrow inline-flex items-center gap-2 rounded-full px-3 py-2 text-foreground ${styles}`} data-testid={`label-${String(children).toLowerCase().replaceAll(' ', '-')}`}><span className="h-1.5 w-1.5 rounded-full bg-current" />{children}</span>;
}

function Home() {
  return (
    <PageFrame>
      <section className="grain overflow-hidden bg-[hsl(var(--secondary))]" data-testid="section-home-hero">
        <div className="page-shell grid min-h-[650px] items-end gap-12 pb-14 pt-14 md:grid-cols-[1.03fr_.97fr] md:pb-20 md:pt-20">
          <div className="relative z-10 self-center">
            <div className="reveal"><SectionTag>Growth Advisor</SectionTag></div>
            <h1 className="display-title reveal reveal-delay-1 mt-7 max-w-[680px] text-[clamp(3.6rem,8vw,7.25rem)]" data-testid="heading-home-hero">Build the Skills.<br /><span className="outline-text">Create the Systems.</span><br />Drive Growth.</h1>
            <p className="reveal reveal-delay-2 mt-7 max-w-[540px] text-[1.05rem] leading-7 text-foreground/70 md:text-[1.15rem]" data-testid="text-home-hero">I help business owners and teams develop practical skills and systems in sales, marketing, and customer support—so they can improve performance and build stronger businesses.</p>
            <div className="reveal reveal-delay-3 mt-9 flex flex-col items-start gap-4 sm:flex-row sm:items-center">
              <a href={consultationLink} target="_blank" rel="noreferrer" className="button-sweep focus-ring inline-flex items-center gap-4 rounded-full bg-foreground px-6 py-4 text-sm font-extrabold uppercase tracking-[.1em] text-background" data-testid="link-hero-work-with-me"><span>Work with me</span><ArrowUpRight size={17} /></a>
              <Link href="/resources" className="focus-ring inline-flex items-center gap-3 px-2 py-3 text-sm font-extrabold text-foreground hover:text-foreground/60" data-testid="link-hero-resources"><span className="border-b border-foreground/40 pb-1">Explore my resources</span><ArrowRight size={17} /></Link>
            </div>
          </div>
          <div className="reveal reveal-delay-2 relative mx-auto w-full max-w-[500px] self-end md:ml-auto">
            <div className="absolute -left-2 top-10 z-10 hidden -rotate-6 rounded-xl border border-foreground/15 bg-background px-4 py-3 shadow-lg sm:block">
              <p className="font-mono-brand text-[.62rem] uppercase tracking-[.14em] text-foreground/55">Founder / Advisor</p>
              <p className="mt-1 text-sm font-extrabold">10+ years in the work</p>
            </div>
            <div className="relative overflow-hidden rounded-[2rem] border-2 border-foreground bg-[hsl(var(--primary))] px-6 pt-8 md:px-10 md:pt-12">
              <div className="absolute right-5 top-5 flex h-16 w-16 items-center justify-center rounded-full border border-foreground/25 bg-background/30">
                <ArrowDownRight size={25} />
              </div>
              <img src={portrait} alt="CC Warsame, Growth Advisor" className="relative z-10 mx-auto block h-auto max-h-[590px] w-full object-contain object-bottom" data-testid="img-hero-portrait" />
              <div className="absolute bottom-6 left-6 z-20 rounded-lg bg-foreground px-4 py-3 text-background md:left-10">
                <p className="eyebrow text-[hsl(var(--secondary))]">CCWARSAME</p>
                <p className="mt-1 text-sm font-bold">Growth, made practical.</p>
              </div>
            </div>
          </div>
        </div>
        <div className="border-t border-foreground/15">
          <div className="page-shell flex min-h-14 flex-wrap items-center gap-x-8 gap-y-2 py-4 text-[.66rem] font-extrabold uppercase tracking-[.16em] text-foreground/55">
            <span>Sales</span><span className="h-1 w-1 rounded-full bg-foreground/45" /><span>Marketing</span><span className="h-1 w-1 rounded-full bg-foreground/45" /><span>Customer support</span><span className="h-1 w-1 rounded-full bg-foreground/45" /><span>Team development</span>
          </div>
        </div>
      </section>

      <section className="page-shell py-24 md:py-32" data-testid="section-home-introduction">
        <div className="grid gap-12 md:grid-cols-[.7fr_1.3fr] md:gap-20">
          <div><SectionTag color="blue">The work</SectionTag><p className="eyebrow mt-7 text-foreground/40">01 / 05</p></div>
          <div>
            <h2 className="display-title max-w-[760px] text-[clamp(2.6rem,6vw,5.5rem)]" data-testid="heading-home-introduction">Growth starts with the right <span className="text-[hsl(var(--primary))]">skills</span> and systems.</h2>
            <p className="mt-8 max-w-[630px] text-lg leading-8 text-foreground/65" data-testid="text-home-introduction">Good growth is rarely hidden in a complicated framework. It lives in the conversations your team has, the process they can repeat, and the decisions they make when no one is watching.</p>
            <Link href="/about" className="focus-ring mt-8 inline-flex items-center gap-3 font-extrabold hover:text-[hsl(var(--primary))]" data-testid="link-home-about"><span className="border-b border-foreground/30 pb-1">See how I work</span><ArrowUpRight size={17} /></Link>
          </div>
        </div>
        <div className="mt-20 grid gap-4 md:grid-cols-3">
          {[
            { n: '01', title: 'Make it clear', copy: 'Find the signal in the noise and give your team a direction they can act on.', color: 'bg-[hsl(var(--primary))]', icon: Compass },
            { n: '02', title: 'Make it repeatable', copy: 'Turn good instincts into simple systems that hold up under real pressure.', color: 'bg-[hsl(var(--secondary))]', icon: Target },
            { n: '03', title: 'Make it move', copy: 'Build the confidence and accountability to keep progress in motion.', color: 'bg-foreground text-background', icon: ArrowUpRight },
          ].map((item) => {
            const Icon = item.icon;
            return <div key={item.n} className={`min-h-[230px] rounded-2xl p-7 ${item.color}`} data-testid={`card-home-principle-${item.n}`}><div className="flex items-start justify-between"><span className="font-mono-brand text-xs opacity-60">{item.n}</span><Icon size={22} /></div><h3 className="mt-14 font-display text-2xl font-bold">{item.title}</h3><p className="mt-3 max-w-[270px] text-sm leading-6 opacity-70">{item.copy}</p></div>;
          })}
        </div>
      </section>

      <section className="bg-foreground py-24 text-background md:py-32" data-testid="section-home-services">
        <div className="page-shell">
          <div className="flex flex-col justify-between gap-8 md:flex-row md:items-end"><div><SectionTag color="lime">Ways to work together</SectionTag><h2 className="display-title mt-7 max-w-[690px] text-[clamp(2.8rem,6vw,5.8rem)]">A sharper way to move your business forward.</h2></div><Link href="/services" className="focus-ring inline-flex shrink-0 items-center gap-3 text-sm font-bold text-background/70 hover:text-background" data-testid="link-home-all-services"><span className="border-b border-background/30 pb-1">All services</span><ArrowUpRight size={17} /></Link></div>
          <div className="mt-16 grid gap-5 md:grid-cols-2">
            <Link href="/services#business-growth" className="card-lift focus-ring group rounded-2xl border border-background/20 bg-[hsl(var(--primary))] p-8 text-foreground md:p-10" data-testid="card-home-business-growth">
              <div className="flex items-start justify-between"><span className="eyebrow opacity-60">01 / Business</span><ArrowUpRight className="transition-transform group-hover:translate-x-1 group-hover:-translate-y-1" /></div>
              <h3 className="mt-20 font-display text-4xl font-bold md:text-5xl">Business<br />growth.</h3><p className="mt-6 max-w-sm text-[.96rem] leading-7 text-foreground/70">Sales strategy, marketing clarity, customer support systems, and an advisor in your corner.</p><span className="mt-9 inline-flex items-center gap-2 text-sm font-extrabold">Explore business growth <ArrowRight size={15} /></span>
            </Link>
            <Link href="/services#team-development" className="card-lift focus-ring group rounded-2xl border border-background/20 bg-[hsl(var(--secondary))] p-8 text-foreground md:mt-16 md:p-10" data-testid="card-home-team-development">
              <div className="flex items-start justify-between"><span className="eyebrow opacity-60">02 / People</span><ArrowUpRight className="transition-transform group-hover:translate-x-1 group-hover:-translate-y-1" /></div>
              <h3 className="mt-20 font-display text-4xl font-bold md:text-5xl">Team<br />development.</h3><p className="mt-6 max-w-sm text-[.96rem] leading-7 text-foreground/70">Practical training and workshops that make capable teams more consistent and confident.</p><span className="mt-9 inline-flex items-center gap-2 text-sm font-extrabold">Explore team development <ArrowRight size={15} /></span>
            </Link>
          </div>
        </div>
      </section>

      <section className="page-shell grid gap-14 py-24 md:grid-cols-[.85fr_1.15fr] md:items-center md:py-32" data-testid="section-home-about">
        <div className="relative mx-auto w-full max-w-[400px]">
          <div className="absolute -bottom-5 -right-5 h-32 w-32 rounded-full border border-[hsl(var(--primary))] md:h-44 md:w-44" />
          <div className="relative overflow-hidden rounded-[2rem] bg-[hsl(var(--muted))] pt-10">
            <img src={portrait} alt="CC Warsame in a black suit" className="mx-auto h-auto w-[88%] object-contain" data-testid="img-home-about-portrait" />
          </div>
          <span className="absolute -left-4 top-10 -rotate-90 font-mono-brand text-[.6rem] uppercase tracking-[.2em] text-foreground/45">Practical over theoretical</span>
        </div>
        <div><SectionTag color="lime">A little context</SectionTag><p className="eyebrow mt-7 text-foreground/40">02 / 05</p><h2 className="display-title mt-5 max-w-[690px] text-[clamp(2.8rem,6vw,5.6rem)]">I’ve learned growth through <span className="text-[hsl(var(--primary))]">experience.</span></h2><p className="mt-8 max-w-[570px] text-lg leading-8 text-foreground/65">I’ve built and scaled businesses, led sales teams, and spent more than a decade in design and marketing. The thread through all of it is simple: helping people do better work by making the next step clear.</p><Link href="/about" className="focus-ring mt-8 inline-flex items-center gap-3 font-extrabold hover:text-[hsl(var(--primary))]" data-testid="link-home-read-story"><span className="border-b border-foreground/30 pb-1">Read the full story</span><ArrowRight size={17} /></Link></div>
      </section>

      <section className="border-y border-foreground/10 bg-[hsl(var(--muted)/.45)] py-24 md:py-32" data-testid="section-home-resources">
        <div className="page-shell"><div className="flex flex-col justify-between gap-8 md:flex-row md:items-end"><div><SectionTag>From the field</SectionTag><h2 className="display-title mt-7 max-w-[700px] text-[clamp(2.7rem,6vw,5.5rem)]">Practical ideas for business and growth.</h2></div><Link href="/resources" className="focus-ring inline-flex items-center gap-3 text-sm font-extrabold" data-testid="link-home-resources-all"><span className="border-b border-foreground/30 pb-1">Browse all resources</span><ArrowUpRight size={17} /></Link></div><div className="mt-14 grid gap-5 md:grid-cols-[1.2fr_.8fr]"><ResourceCard resource={resources[0]} featured /><div className="grid gap-5 sm:grid-cols-2 md:grid-cols-1"><ResourceCard resource={resources[1]} /><ResourceCard resource={resources[2]} /></div></div></div>
      </section>

      <section className="page-shell py-24 md:py-32" data-testid="section-home-cta">
        <div className="relative overflow-hidden rounded-[2rem] bg-[hsl(var(--primary))] px-7 py-14 md:px-16 md:py-20"><div className="absolute -right-10 -top-24 h-72 w-72 rounded-full border-[32px] border-foreground/10" /><div className="relative z-10 max-w-[780px]"><SectionTag color="ink">Next step</SectionTag><h2 className="display-title mt-7 text-[clamp(2.9rem,7vw,6.8rem)]" data-testid="heading-home-cta">Ready to build your next level of growth?</h2><p className="mt-7 max-w-[520px] text-lg leading-7 text-foreground/70">Bring the challenge, the ambition, or simply the question. We’ll find the useful next move together.</p><a href={consultationLink} target="_blank" rel="noreferrer" className="button-sweep focus-ring mt-9 inline-flex items-center gap-4 rounded-full bg-foreground px-6 py-4 text-sm font-extrabold uppercase tracking-[.1em] text-background" data-testid="link-home-cta"><span>Start a conversation</span><ArrowUpRight size={17} /></a></div></div>
      </section>
    </PageFrame>
  );
}

function ResourceCard({ resource, featured = false }: { resource: Resource; featured?: boolean }) {
  const cardTone = resource.color === 'lime' ? 'bg-[hsl(var(--secondary))] text-foreground' : resource.color === 'ink' ? 'bg-foreground text-background' : 'bg-[hsl(var(--primary))] text-foreground';
  return <article className={`card-lift ${cardTone} rounded-2xl p-7 ${featured ? 'min-h-[390px] md:p-10' : 'min-h-[210px]'}`} data-testid={`card-resource-${resource.id}`}><div className="flex items-start justify-between gap-4"><span className="eyebrow opacity-60">{resource.type}</span><BookOpen size={18} /></div><h3 className={`${featured ? 'mt-24 text-3xl md:text-4xl' : 'mt-8 text-xl'} max-w-[560px] font-display font-bold leading-tight`}>{resource.title}</h3><p className={`mt-4 max-w-[520px] text-sm leading-6 ${resource.color === 'ink' ? 'text-background/60' : 'text-foreground/65'}`}>{resource.description}</p><div className="mt-6 flex items-center gap-2 text-xs font-bold opacity-60"><Clock3 size={14} /> {resource.readTime}</div></article>;
}

function PageIntro({ number, tag, title, copy, color = 'blue' }: { number: string; tag: string; title: ReactNode; copy: string; color?: 'blue' | 'lime' }) {
  return <section className={`border-b border-foreground/10 ${color === 'lime' ? 'bg-[hsl(var(--secondary))]' : 'bg-[hsl(var(--primary))]'}`} data-testid={`section-page-intro-${number}`}><div className="page-shell grid min-h-[470px] items-end gap-10 pb-14 pt-16 md:grid-cols-[.65fr_1.35fr] md:pb-20 md:pt-24"><div><SectionTag color={color}>{tag}</SectionTag><p className="eyebrow mt-7 text-foreground/50">{number} / 05</p></div><div><h1 className="display-title max-w-[900px] text-[clamp(3.2rem,8vw,8rem)]" data-testid={`heading-page-${tag.toLowerCase().replaceAll(' ', '-')}`}>{title}</h1><p className="mt-8 max-w-[620px] text-lg leading-8 text-foreground/70" data-testid={`text-page-${tag.toLowerCase().replaceAll(' ', '-')}`}>{copy}</p></div></div></section>;
}

function About() {
  return <PageFrame><PageIntro number="02" tag="The person behind the work" title={<>Experience that stays close to the <span className="outline-text">real work.</span></>} copy="I’m CC Warsame, a Growth Advisor who helps businesses and teams turn ambition into clearer decisions, stronger habits, and systems that actually get used." color="lime" />
    <section className="page-shell grid gap-14 py-24 md:grid-cols-[.75fr_1.25fr] md:py-32" data-testid="section-about-story">
      <div className="md:pt-3"><SectionTag>My story</SectionTag><p className="eyebrow mt-7 text-foreground/40">How I got here</p></div>
      <div><h2 className="display-title max-w-[720px] text-[clamp(2.6rem,5vw,4.8rem)]">The best advice is usually earned before it is explained.</h2><div className="mt-9 max-w-[670px] space-y-5 text-[1.05rem] leading-8 text-foreground/68"><p>I’ve spent my career close to the point where plans meet people. Building and scaling businesses. Leading sales teams. Working across design and marketing for more than a decade. Learning what makes a customer lean in—and what makes a team lose momentum.</p><p>That experience shaped how I advise today. No theatre. No oversized deck that disappears after the meeting. We work on the thing in front of us, build the capability around it, and leave behind a system that can keep working.</p></div><div className="mt-12 grid gap-4 sm:grid-cols-3">{[{ value: '10+', label: 'years in design & marketing' }, { value: '03', label: 'growth levers I work across' }, { value: '01', label: 'practical next step at a time' }].map((stat) => <div key={stat.label} className="border-t-2 border-foreground pt-4" data-testid={`stat-about-${stat.label.replaceAll(' ', '-')}`}><p className="font-display text-3xl font-bold">{stat.value}</p><p className="mt-2 text-xs leading-5 text-foreground/55">{stat.label}</p></div>)}</div></div>
    </section>
    <section className="bg-foreground py-24 text-background md:py-32" data-testid="section-about-principles"><div className="page-shell grid gap-14 md:grid-cols-[.7fr_1.3fr]"><div><SectionTag color="lime">How I think</SectionTag><p className="eyebrow mt-7 text-background/45">Three working beliefs</p></div><div className="divide-y divide-background/15">{[{num:'01',title:'Execution is the teacher.',copy:'The plan gets smarter once it meets a real customer, a real team, and a real Tuesday morning.'},{num:'02',title:'Clarity is a growth tool.',copy:'When people know what matters, why it matters, and what good looks like, the work gets lighter and better.'},{num:'03',title:'Systems should serve people.',copy:'A process is only useful if the people inside it can understand it, trust it, and make it their own.'}].map((item) => <div key={item.num} className="grid gap-5 py-9 md:grid-cols-[80px_1fr] md:gap-8"><span className="font-mono-brand text-xs text-[hsl(var(--secondary))]">{item.num}</span><div><h3 className="font-display text-3xl font-bold md:text-4xl">{item.title}</h3><p className="mt-4 max-w-[510px] leading-7 text-background/55">{item.copy}</p></div></div>)}</div></div></section>
    <section className="page-shell grid gap-12 py-24 md:grid-cols-[1fr_1fr] md:items-center md:py-32" data-testid="section-about-portrait"><div className="overflow-hidden rounded-[2rem] bg-[hsl(var(--muted))]"><img src={portrait} alt="CC Warsame, Growth Advisor" className="mx-auto h-auto max-h-[660px] w-full object-contain" data-testid="img-about-portrait" /></div><div className="md:pl-8"><SectionTag color="blue">The philosophy</SectionTag><blockquote className="mt-7 font-display text-[clamp(2.4rem,5vw,4.7rem)] font-bold leading-[1.02]" data-testid="quote-about-philosophy">“Build the Skills. Create the Systems. Drive Growth.”</blockquote><p className="mt-7 max-w-[460px] leading-7 text-foreground/60">It’s more than a line on a website. It’s the sequence I bring to every engagement: grow the capability, make the work repeatable, then let the results compound.</p><a href={consultationLink} target="_blank" rel="noreferrer" className="focus-ring mt-8 inline-flex items-center gap-3 font-extrabold hover:text-[hsl(var(--primary))]" data-testid="link-about-work-with-me"><span className="border-b border-foreground/30 pb-1">Work with me</span><ArrowUpRight size={17} /></a></div></section>
  </PageFrame>;
}

const businessServices = ['Sales strategy and pipeline clarity', 'Marketing strategy and campaign focus', 'Customer support systems', 'Business process improvement', 'Ongoing growth advisory'];
const teamServices = ['Sales training and conversation practice', 'Customer service training', 'Marketing workshops', 'Team performance improvement', 'Practical training programs'];

function ServiceList({ items }: { items: string[] }) {
  return <ul className="mt-8 divide-y divide-foreground/15">{items.map((item, index) => <li key={item} className="flex items-center gap-4 py-4 text-sm font-semibold" data-testid={`service-item-${index}`}><span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-foreground/30"><Check size={13} /></span>{item}</li>)}</ul>;
}

function Services() {
  return (
    <PageFrame>
      <PageIntro number="03" tag="What I help with" title={<>Useful help for the <span className="outline-text">next move.</span></>} copy="Whether you’re improving the business or strengthening the team inside it, we focus on practical progress that your people can carry forward." />
      <section className="page-shell py-24 md:py-32" data-testid="section-services-offerings">
        <div id="business-growth" className="scroll-mt-28 grid gap-10 border-b border-foreground/15 pb-20 md:grid-cols-[.8fr_1.2fr] md:gap-20 md:pb-28">
          <div>
            <SectionTag>01 / Business growth</SectionTag>
            <h2 className="display-title mt-7 max-w-[470px] text-[clamp(2.7rem,5vw,5rem)]">Make the business easier to <span className="text-[hsl(var(--primary))]">grow.</span></h2>
            <p className="mt-7 max-w-[430px] leading-7 text-foreground/62">For owners and leaders who want a clearer path from good ideas to better commercial performance.</p>
            <a href={consultationLink} target="_blank" rel="noreferrer" className="button-sweep focus-ring mt-8 inline-flex items-center gap-3 rounded-full bg-foreground px-5 py-3.5 text-xs font-extrabold uppercase tracking-[.1em] text-background" data-testid="link-services-business-contact"><span>Talk about your business</span><ArrowUpRight size={15} /></a>
          </div>
          <div className="rounded-2xl bg-[hsl(var(--primary))] p-7 md:p-10">
            <div className="flex items-start justify-between"><div className="flex h-14 w-14 items-center justify-center rounded-full border border-foreground/30"><Compass size={25} /></div><span className="font-mono-brand text-xs opacity-50">STRATEGY / SYSTEMS / MOMENTUM</span></div>
            <h3 className="mt-20 font-display text-3xl font-bold md:text-4xl">A growth system that your team can actually run.</h3>
            <ServiceList items={businessServices} />
          </div>
        </div>
        <div id="team-development" className="scroll-mt-28 grid gap-10 pt-20 md:grid-cols-[.8fr_1.2fr] md:gap-20 md:pt-28">
          <div>
            <SectionTag color="lime">02 / Team development</SectionTag>
            <h2 className="display-title mt-7 max-w-[470px] text-[clamp(2.7rem,5vw,5rem)]">Give good people a better way to <span className="text-[hsl(var(--primary))]">perform.</span></h2>
            <p className="mt-7 max-w-[430px] leading-7 text-foreground/62">For teams ready to build practical capability, improve their conversations, and create a stronger standard of work.</p>
            <a href={consultationLink} target="_blank" rel="noreferrer" className="button-sweep focus-ring mt-8 inline-flex items-center gap-3 rounded-full bg-foreground px-5 py-3.5 text-xs font-extrabold uppercase tracking-[.1em] text-background" data-testid="link-services-team-contact"><span>Plan a team session</span><ArrowUpRight size={15} /></a>
          </div>
          <div className="rounded-2xl bg-[hsl(var(--secondary))] p-7 md:p-10">
            <div className="flex items-start justify-between"><div className="flex h-14 w-14 items-center justify-center rounded-full border border-foreground/30"><Users size={25} /></div><span className="font-mono-brand text-xs opacity-50">PEOPLE / PRACTICE / PROGRESS</span></div>
            <h3 className="mt-20 font-display text-3xl font-bold md:text-4xl">Training people can use the next day.</h3>
            <ServiceList items={teamServices} />
          </div>
        </div>
      </section>
      <section className="bg-[hsl(var(--muted)/.5)] py-24 md:py-32" data-testid="section-services-process">
        <div className="page-shell">
          <div className="grid gap-10 md:grid-cols-[.7fr_1.3fr]">
            <div><SectionTag>How it works</SectionTag><p className="eyebrow mt-7 text-foreground/40">Simple by design</p></div>
            <div>
              <h2 className="display-title max-w-[680px] text-[clamp(2.7rem,5vw,5rem)]">No mystery. Just a useful process.</h2>
              <div className="mt-12 grid gap-5 sm:grid-cols-3">{[{num:'01',title:'Listen',copy:'Understand the context, the friction, and what is already working.'},{num:'02',title:'Build',copy:'Shape the strategy, practice, or system around the real need.'},{num:'03',title:'Hand over',copy:'Leave your team with clarity, confidence, and something they can own.'}].map((step) => <div key={step.num} className="border-t-2 border-foreground pt-5" data-testid={`card-service-process-${step.num}`}><span className="font-mono-brand text-xs text-foreground/45">{step.num}</span><h3 className="mt-12 font-display text-2xl font-bold">{step.title}</h3><p className="mt-3 text-sm leading-6 text-foreground/60">{step.copy}</p></div>)}</div>
            </div>
          </div>
        </div>
      </section>
      <section className="page-shell py-24 md:py-32" data-testid="section-services-cta">
        <div className="flex flex-col items-start justify-between gap-8 rounded-2xl border-2 border-foreground p-7 md:flex-row md:items-center md:p-10">
          <div><p className="eyebrow text-[hsl(var(--primary))]">Have a challenge in mind?</p><h2 className="mt-3 font-display text-3xl font-bold md:text-4xl">Let’s make the next move useful.</h2></div>
          <a href={consultationLink} target="_blank" rel="noreferrer" className="button-sweep focus-ring inline-flex shrink-0 items-center gap-3 rounded-full bg-foreground px-6 py-4 text-sm font-extrabold uppercase tracking-[.1em] text-background" data-testid="link-services-cta"><span>Start a conversation</span><ArrowUpRight size={17} /></a>
        </div>
      </section>
    </PageFrame>
  );
}

function Resources() {
  const [category, setCategory] = useState('All');
  const [selected, setSelected] = useState<Resource | null>(null);
  const categories = ['All', 'Sales', 'Marketing', 'Customer support', 'Business growth', 'Team development'];
  const filtered = useMemo(() => category === 'All' ? resources : resources.filter((resource) => resource.type.toLowerCase().includes(category.split(' ')[0].toLowerCase()) || resource.title.toLowerCase().includes(category.split(' ')[0].toLowerCase()) || (category === 'Business growth' && ['Field note', 'Checklist'].includes(resource.type)) || (category === 'Team development' && ['Workshop note', 'Video'].includes(resource.type))), [category]);
  return <PageFrame><PageIntro number="04" tag="The resource shelf" title={<>Ideas to help you <span className="outline-text">do the work.</span></>} copy="Short, practical notes on sales, marketing, customer support, growth, and the team habits that make all of them stronger." color="lime" />
     <section className="page-shell py-20 md:py-28" data-testid="section-resources-library"><div className="flex flex-col justify-between gap-6 border-b border-foreground/15 pb-7 md:flex-row md:items-end"><div><SectionTag>Browse the library</SectionTag><p className="mt-4 text-sm text-foreground/55">A growing collection from the field.</p></div><div className="flex flex-wrap gap-2" role="tablist" aria-label="Resource categories">{categories.map((item) => <button type="button" key={item} onClick={() => setCategory(item)} className={`focus-ring rounded-full border px-3 py-2 text-xs font-bold transition ${category === item ? 'border-foreground bg-foreground text-background' : 'border-foreground/20 hover:border-foreground'}`} aria-selected={category === item} data-testid={`button-resource-filter-${item.toLowerCase().replaceAll(' ', '-')}`}>{item}</button>)}</div></div><div className="mt-10 grid gap-5 md:grid-cols-2">{filtered.map((resource) => <button type="button" key={resource.id} onClick={() => setSelected(resource)} className="text-left" data-testid={`button-open-resource-${resource.id}`}><ResourceCard resource={resource} /></button>)}</div>{filtered.length === 0 && <div className="py-20 text-center" data-testid="empty-resources"><p className="font-display text-2xl font-bold">More notes are on the way.</p><p className="mt-2 text-foreground/55">Try another category for now.</p></div>}</section>
    {selected && <div className="fixed inset-0 z-50 flex items-end justify-center bg-foreground/40 p-4 backdrop-blur-sm md:items-center" role="dialog" aria-modal="true" aria-label={selected.title} data-testid="dialog-resource"><div className="relative max-h-[90vh] w-full max-w-[620px] overflow-auto rounded-2xl bg-background p-7 md:p-10"><button type="button" onClick={() => setSelected(null)} className="focus-ring absolute right-5 top-5 rounded-full border border-foreground/20 p-2" aria-label="Close resource" data-testid="button-close-resource"><X size={18} /></button><SectionTag color={selected.color === 'ink' ? 'blue' : selected.color}>{selected.type}</SectionTag><h2 className="display-title mt-7 max-w-[500px] text-4xl">{selected.title}</h2><p className="mt-6 text-base leading-8 text-foreground/65">{selected.description}</p><div className="mt-8 rounded-xl bg-[hsl(var(--muted))] p-5"><p className="eyebrow text-foreground/45">A useful prompt</p><p className="mt-3 text-lg font-bold">What would become easier if your team had one clear way to do it?</p></div><button type="button" onClick={() => setSelected(null)} className="button-sweep focus-ring mt-8 inline-flex items-center gap-3 rounded-full bg-foreground px-5 py-3.5 text-xs font-extrabold uppercase tracking-[.1em] text-background" data-testid="button-close-resource-done"><span>Back to resources</span><ArrowRight size={15} /></button></div></div>}
  </PageFrame>;
}

type FormValues = { name: string; email: string; company: string; interest: string; message: string };
const initialForm: FormValues = { name: '', email: '', company: '', interest: '', message: '' };

function Contact() {
  const [values, setValues] = useState(initialForm);
  const [errors, setErrors] = useState<Partial<FormValues>>({});
  const [submitted, setSubmitted] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const update = (field: keyof FormValues, value: string) => setValues((current) => ({ ...current, [field]: value }));
  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const next: Partial<FormValues> = {};
    if (!values.name.trim()) next.name = 'Please add your name.';
    if (!values.email.trim() || !/^\S+@\S+\.\S+$/.test(values.email)) next.email = 'Please enter a valid email.';
    if (!values.interest) next.interest = 'Choose what you want to explore.';
    if (!values.message.trim() || values.message.trim().length < 15) next.message = 'Tell me a little more (at least 15 characters).';
    setErrors(next);
    if (Object.keys(next).length > 0) return;
    setIsSending(true);
    window.setTimeout(() => { setIsSending(false); setSubmitted(true); }, 650);
  };
  if (submitted) return <PageFrame><section className="min-h-[calc(100vh-76px)] bg-[hsl(var(--secondary))] py-20 md:py-32" data-testid="section-contact-success"><div className="page-shell grid max-w-[950px] gap-14 md:grid-cols-[.7fr_1.3fr] md:items-center"><div className="flex h-24 w-24 items-center justify-center rounded-full bg-foreground text-background"><Check size={38} /></div><div><SectionTag color="ink">Message received</SectionTag><h1 className="display-title mt-7 text-[clamp(3.4rem,8vw,7.5rem)]" data-testid="heading-contact-success">Good. We’ve got a starting point.</h1><p className="mt-7 max-w-[550px] text-lg leading-8 text-foreground/70">Thanks for reaching out, {values.name.split(' ')[0] || 'there'}. I’ll read through the details and get back to you at {values.email} soon.</p><Link href="/" className="focus-ring mt-9 inline-flex items-center gap-3 font-extrabold" data-testid="link-contact-success-home"><span className="border-b border-foreground/30 pb-1">Back to home</span><ArrowUpRight size={17} /></Link></div></div></section></PageFrame>;
  return <PageFrame><PageIntro number="05" tag="Let’s talk" title={<>Bring the challenge. We’ll find the <span className="outline-text">next move.</span></>} copy="Tell me what you’re building, improving, or trying to untangle. A few useful details is all we need to begin." />
    <section className="page-shell grid gap-14 py-20 md:grid-cols-[.7fr_1.3fr] md:py-28" data-testid="section-contact-form"><div><SectionTag>Start here</SectionTag><div className="mt-10 space-y-7"><div><p className="eyebrow text-foreground/40">Email</p><a href="mailto:hello@ccwarsame.com" className="focus-ring mt-2 inline-block text-lg font-bold hover:text-[hsl(var(--primary))]" data-testid="link-contact-email">hello@ccwarsame.com</a></div><div><p className="eyebrow text-foreground/40">Based in</p><p className="mt-2 flex items-center gap-2 text-lg font-bold"><MapPin size={17} className="text-[hsl(var(--primary))]" /> East Africa, working globally</p></div><div><p className="eyebrow text-foreground/40">Usually responds</p><p className="mt-2 flex items-center gap-2 text-lg font-bold"><Clock3 size={17} className="text-[hsl(var(--primary))]" /> Within 2 business days</p></div></div><div className="mt-12 border-t border-foreground/15 pt-7"><p className="text-sm leading-6 text-foreground/58">Prefer a quick hello? Find me on the places where ideas and conversations tend to happen.</p><div className="mt-5 flex gap-3"><a href={socialLinks.facebook} target="_blank" rel="noreferrer" className="focus-ring rounded-full border border-foreground/20 p-3 transition hover:border-foreground" aria-label="Facebook" data-testid="link-contact-facebook"><Facebook size={17} /></a><a href={socialLinks.linkedin} target="_blank" rel="noreferrer" className="focus-ring rounded-full border border-foreground/20 p-3 transition hover:border-foreground" aria-label="LinkedIn" data-testid="link-contact-linkedin"><Linkedin size={17} /></a><a href={socialLinks.whatsapp} target="_blank" rel="noreferrer" className="focus-ring rounded-full border border-foreground/20 p-3 transition hover:border-foreground" aria-label="WhatsApp" data-testid="link-contact-whatsapp"><MessageCircle size={17} /></a></div></div></div>
      <form onSubmit={submit} noValidate className="rounded-2xl bg-[hsl(var(--muted)/.55)] p-6 md:p-10" data-testid="form-contact"><div className="grid gap-6 sm:grid-cols-2"><Field label="Your name" value={values.name} onChange={(value) => update('name', value)} error={errors.name} placeholder="Name" testId="input-contact-name" required /><Field label="Work email" type="email" value={values.email} onChange={(value) => update('email', value)} error={errors.email} placeholder="you@company.com" testId="input-contact-email" required /><Field label="Company or project" value={values.company} onChange={(value) => update('company', value)} error={errors.company} placeholder="What are you building?" testId="input-contact-company" /><div><label htmlFor="interest" className="eyebrow text-foreground/55">I’m interested in</label><div className="relative mt-3"><select id="interest" value={values.interest} onChange={(event) => update('interest', event.target.value)} className="focus-ring w-full appearance-none rounded-lg border border-foreground/20 bg-background px-4 py-3.5 text-sm outline-none transition focus:border-[hsl(var(--primary))]" data-testid="select-contact-interest"><option value="">Choose one</option><option value="business-growth">Business growth advisory</option><option value="team-development">Team development</option><option value="workshop">A workshop or training</option><option value="other">Something else</option></select><ChevronDown size={16} className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-foreground/45" /></div>{errors.interest && <p className="mt-2 text-xs font-semibold text-[hsl(var(--destructive))]" data-testid="error-contact-interest">{errors.interest}</p>}</div></div><div className="mt-6"><label htmlFor="message" className="eyebrow text-foreground/55">A little about the challenge <span className="text-[hsl(var(--primary))]">*</span></label><textarea id="message" rows={6} value={values.message} onChange={(event) => update('message', event.target.value)} placeholder="What would you like to make clearer, stronger, or easier?" className="focus-ring mt-3 w-full resize-y rounded-lg border border-foreground/20 bg-background px-4 py-3.5 text-sm leading-6 outline-none transition focus:border-[hsl(var(--primary))]" data-testid="textarea-contact-message" />{errors.message && <p className="mt-2 text-xs font-semibold text-[hsl(var(--destructive))]" data-testid="error-contact-message">{errors.message}</p>}</div><button type="submit" disabled={isSending} className="button-sweep focus-ring mt-7 inline-flex items-center gap-3 rounded-full bg-foreground px-6 py-4 text-sm font-extrabold uppercase tracking-[.1em] text-background disabled:cursor-wait disabled:opacity-70" data-testid="button-submit-contact"><span>{isSending ? 'Sending…' : 'Send inquiry'}</span>{isSending ? <span className="h-4 w-4 animate-pulse rounded-full bg-[hsl(var(--secondary))]" /> : <Send size={16} />}</button><p className="mt-4 text-xs text-foreground/45">No mailing list. No automated sales sequence. Just a considered reply.</p></form>
    </section>
  </PageFrame>;
}

function Field({ label, value, onChange, error, placeholder, type = 'text', testId, required = false }: { label: string; value: string; onChange: (value: string) => void; error?: string; placeholder: string; type?: string; testId: string; required?: boolean }) {
  return <div><label htmlFor={testId} className="eyebrow text-foreground/55">{label} {required && <span className="text-[hsl(var(--primary))]">*</span>}</label><input id={testId} type={type} value={value} onChange={(event) => onChange(event.target.value)} placeholder={placeholder} className="focus-ring mt-3 w-full rounded-lg border border-foreground/20 bg-background px-4 py-3.5 text-sm outline-none transition placeholder:text-foreground/35 focus:border-[hsl(var(--primary))]" data-testid={testId} />{error && <p className="mt-2 text-xs font-semibold text-[hsl(var(--destructive))]" data-testid={`error-${testId}`}>{error}</p>}</div>;
}

function Router() {
  return <><PageScrollManager /><ErrorBoundary><Switch><Route path="/" component={Home} /><Route path="/about" component={About} /><Route path="/services" component={Services} /><Route path="/resources" component={Resources} /><Route path="/contact" component={Contact} /><Route component={NotFound} /></Switch></ErrorBoundary></>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;